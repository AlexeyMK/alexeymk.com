---
layout: post
title: ! 'Hackathon - A retrospective - a talk'
published: true
description: in February about a hackathon we ostensibly threw.
date: 2015-06-22 19:53:52
tags:
- hackathons
- talks
---

[Nick Meyer](https://twitter.com/nickemeyer) and I gave a talk at [HackCon II](http://hackcon.io) in February about a hackathon we ostensibly threw.

<div class="ratio ratio-16x9">
<iframe data-src="https://www.youtube.com/embed/cBRMuPBtTN0?rel=0" class="lazyload" loading="lazy" allowfullscreen></iframe>
</div>


[Hackcon III](http://hackcon.io) is at Github HQ in SF this summer.
