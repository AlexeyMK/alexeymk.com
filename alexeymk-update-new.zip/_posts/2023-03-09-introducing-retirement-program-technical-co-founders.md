---
layout: post
title: 'Introducing: A Retirement Program for Technical Co-Founders'
description: Exhausted from running your startup? Burnt out, losing friends and hair, gaining weight and wrinkles?
published: true
cover: https://alexeymk-com.pages.dev/assets/img/blog/gwt.png
date: 2023-03-09 16:00:29
tags:
 - growth-eng
---

Exhausted from running your startup? Burnt out, losing friends and hair, gaining weight and wrinkles?

Now, there’s a better way. Introducing: a career in Growth Engineering™️.

Now, I hear what you’re saying.  “Isn’t that just Engineering? That’s what I was doing before I started this company, I don’t know if I want to go back to PMs telling me what to do, that’s why I became a founder in the first place.” 

Well, good news! With Growth Engineering™️, you can still drive a significant portion of what you work on, and be responsible for moving a business metric vs coding a feature. The best Growth Engineers are effectively Mini-PMs. And if you join now, as an added bonus, we’ll throw in: having a stable job and being able to leave work at a reasonable hour!

{% include widget/subscribe.html %}

Don’t believe me? Meet circa-2018 Alexey, a retired Co-Founder. How are you doing Alexey? 

Circa-2018 Alexey: “Great! I moved our funnel conversion by 10% last week through one simple experiment. And with my new free time, I’m competing in my first Triathlon next week!

Good luck with that Circa-2018 Alexey! And best of all, if you end up wanting to get back in the co-founder saddle, that’s always an option.

  

Growth Engineering™️ - order today and we’ll throw in a generous salary + benefits package!